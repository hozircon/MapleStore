---
agent: speckit.analyze
---
