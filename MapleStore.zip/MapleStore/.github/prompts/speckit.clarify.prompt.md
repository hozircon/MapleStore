---
agent: speckit.clarify
---
