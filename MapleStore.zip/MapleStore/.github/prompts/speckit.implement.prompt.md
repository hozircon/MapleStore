---
agent: speckit.implement
---
