---
agent: speckit.constitution
---
